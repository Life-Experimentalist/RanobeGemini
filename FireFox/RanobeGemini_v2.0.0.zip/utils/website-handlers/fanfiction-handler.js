/**
 * FanFiction.net Website Content Handler
 * Specialized handler for extracting content from FanFiction.net
 */
import { BaseWebsiteHandler } from "./base-handler.js";

export class FanFictionHandler extends BaseWebsiteHandler {
	constructor() {
		super();
		this.selectors = {
			content: [
				"#storytext", // FanFiction.net main content area
				".storytextp",
				".storytext",
				"#story_text",
			],
			title: ["#profile_top b.xcontrast_txt", ".gui_title"],
		};
	}

	canHandle() {
		return window.location.hostname.includes("fanfiction.net");
	}

	findContentArea() {
		// Try each content selector
		for (const selector of this.selectors.content) {
			const element = document.querySelector(selector);
			if (element) {
				console.log(
					`FanFiction: Content area found using selector: ${selector}`
				);
				return element;
			}
		}

		// Fallback to parent's implementation
		const fallback = super.findContentArea();
		if (fallback) {
			console.log("FanFiction: Found content via fallback method");
			return fallback;
		}

		return null;
	}

	extractTitle() {
		// Try each title selector
		for (const selector of this.selectors.title) {
			const titleElement = document.querySelector(selector);
			if (titleElement && titleElement.innerText.trim()) {
				return titleElement.innerText.trim();
			}
		}

		// Fallback to document title
		let title = document.title || "Unknown Title";

		// Clean up title if needed - FF.net has format "Title Chapter X, a category fanfic | FanFiction"
		const titleMatch = title.match(
			/(.*?)(?:Chapter \d+)?(?:, a .*? fanfic)?\s*\|/i
		);
		if (titleMatch && titleMatch[1]) {
			title = titleMatch[1].trim();
		}

		// Get chapter title if available
		let chapterTitle = "";
		const chapterSelect = document.querySelector("#chap_select");
		if (chapterSelect && chapterSelect.selectedOptions[0]) {
			chapterTitle = chapterSelect.selectedOptions[0].textContent.trim();
		}

		// Combine title and chapter if both exist
		return chapterTitle ? `${title} - ${chapterTitle}` : title;
	}

	extractContent() {
		const contentArea = this.findContentArea();
		if (!contentArea) {
			return {
				found: false,
				title: "",
				text: "",
				selector: "",
			};
		}

		const chapterTitle = this.extractTitle();

		// Create a deep clone to prevent modifying the actual DOM
		const contentClone = contentArea.cloneNode(true);

		// Get clean text content
		let chapterText = contentClone.innerText
			.trim()
			.replace(/\n\s+/g, "\n") // Preserve paragraph breaks but remove excess whitespace
			.replace(/\s{2,}/g, " "); // Replace multiple spaces with a single space

		return {
			found: chapterText.length > 100,
			title: chapterTitle,
			text: chapterText,
			selector: "fanfiction-handler",
		};
	}

	getChapterNavigation() {
		// Find chapter navigation elements
		const chapterSelect = document.querySelector("#chap_select");
		let currentChapter = 1;
		let totalChapters = 1;

		if (chapterSelect) {
			const options = chapterSelect.querySelectorAll("option");
			totalChapters = options.length;

			// Find selected option
			const selectedOption = chapterSelect.selectedOptions[0];
			if (selectedOption) {
				const chapterMatch = selectedOption.textContent.match(/(\d+)/);
				if (chapterMatch && chapterMatch[1]) {
					currentChapter = parseInt(chapterMatch[1], 10);
				}
			}
		}

		// Determine if previous/next chapters exist
		const hasPrevious = currentChapter > 1;
		const hasNext = currentChapter < totalChapters;

		return {
			hasPrevious,
			hasNext,
			currentChapter,
			totalChapters,
		};
	}

	getUIInsertionPoint(contentArea) {
		// Look for the chapter selection area which is a good insertion point
		const chapterControls = document.querySelector("#chap_select");
		if (chapterControls && chapterControls.parentNode) {
			return {
				element: chapterControls.parentNode.nextSibling,
				position: "before",
			};
		}

		// Fallback to inserting before the content area
		return {
			element: contentArea,
			position: "before",
		};
	}
}

// Default export
export default new FanFictionHandler();
