// Shared chunking utilities for background and content scripts
// Provides consistent splitting and merging logic for large chapter text

const DEFAULT_MAX_CHUNK_SIZE = 20000;
export const MIN_CHUNK_LENGTH = 200;

function getLoggers(options = {}) {
	const logger = options.logger || console;
	const logEnabled = options.logEnabled !== false;
	const log = logEnabled && logger?.log ? logger.log.bind(logger) : () => {};
	const warn = logger?.warn ? logger.warn.bind(logger) : () => {};
	const error = logger?.error ? logger.error.bind(logger) : () => {};
	const logPrefix = options.logPrefix || "[Chunking]";

	return { log, warn, error, logPrefix };
}

function mergeSmallChunks(chunks, minChunkLength = MIN_CHUNK_LENGTH) {
	const mergedChunks = [];
	chunks.forEach((chunk) => {
		if (mergedChunks.length > 0 && chunk.length < minChunkLength) {
			mergedChunks[mergedChunks.length - 1] = (
				mergedChunks[mergedChunks.length - 1] +
				" " +
				chunk
			).trim();
		} else {
			mergedChunks.push(chunk);
		}
	});

	if (
		mergedChunks.length > 1 &&
		mergedChunks[mergedChunks.length - 1].length < minChunkLength
	) {
		mergedChunks[mergedChunks.length - 2] = (
			mergedChunks[mergedChunks.length - 2] +
			" " +
			mergedChunks.pop()
		).trim();
	}

	return mergedChunks;
}

export function splitContentForProcessing(
	content,
	maxChunkSize = DEFAULT_MAX_CHUNK_SIZE,
	options = {}
) {
	const { log, warn, error, logPrefix } = getLoggers(options);

	log(
		`${logPrefix} Starting splitContentForProcessing with maxChunkSize=${maxChunkSize}`
	);
	log(`${logPrefix} Content length: ${content?.length || 0} chars`);

	if (!content || typeof content !== "string") {
		error(`${logPrefix} Invalid content provided`);
		return [content || ""];
	}

	if (content.length <= maxChunkSize) {
		log(`${logPrefix} Content is small enough, no splitting needed`);
		return [content];
	}

	let chunks = [];
	let splitParts = [];

	splitParts = content.split(/\n\s*\n/);
	log(
		`${logPrefix} Strategy 1 (double newlines): ${splitParts.length} parts`
	);

	if (splitParts.length <= 1) {
		splitParts = content.split(/\n/);
		log(
			`${logPrefix} Strategy 2 (single newlines): ${splitParts.length} parts`
		);
	}

	if (splitParts.length <= 1) {
		splitParts = content.split(/(?<=[.!?])\s+(?=[A-Z])/);
		log(
			`${logPrefix} Strategy 3 (sentence boundaries): ${splitParts.length} parts`
		);
	}

	if (splitParts.length <= 1) {
		splitParts = content.split(/(?<=[.!?])\s+/);
		log(
			`${logPrefix} Strategy 4 (any sentence ending): ${splitParts.length} parts`
		);
	}

	let currentChunk = "";

	for (let i = 0; i < splitParts.length; i++) {
		const part = splitParts[i];
		if (!part) continue;

		const separator = currentChunk ? " " : "";

		if (
			currentChunk.length + separator.length + part.length >
				maxChunkSize &&
			currentChunk.length > 0
		) {
			chunks.push(currentChunk.trim());
			currentChunk = part;
		} else {
			currentChunk += separator + part;
		}
	}

	if (currentChunk.trim()) {
		chunks.push(currentChunk.trim());
	}

	log(`${logPrefix} After part-based splitting: ${chunks.length} chunks`);

	const finalChunks = [];
	for (const chunk of chunks) {
		if (chunk.length <= maxChunkSize) {
			finalChunks.push(chunk);
		} else {
			warn(
				`${logPrefix} Chunk too large (${chunk.length} chars), force splitting by words`
			);
			const words = chunk.split(/\s+/);
			let subChunk = "";

			for (const word of words) {
				if (
					subChunk.length + word.length + 1 > maxChunkSize &&
					subChunk.length > 0
				) {
					finalChunks.push(subChunk.trim());
					subChunk = word;
				} else {
					subChunk += (subChunk ? " " : "") + word;
				}
			}

			if (subChunk.trim()) {
				finalChunks.push(subChunk.trim());
			}
		}
	}

	const validChunks = finalChunks.filter((c) => c && c.trim().length > 0);

	const mergedChunks = mergeSmallChunks(validChunks, options.minChunkLength);

	log(`${logPrefix} Final result: ${mergedChunks.length} chunks`);
	log(
		`${logPrefix} Chunk sizes: ${mergedChunks
			.map((c, i) => `[${i}]=${c.length}`)
			.join(", ")}`
	);

	mergedChunks.forEach((chunk, idx) => {
		log(
			`${logPrefix} Chunk ${idx} preview: "${chunk.substring(0, 100)}..."`
		);
	});

	return mergedChunks.length > 0 ? mergedChunks : [content];
}

export const chunkingDefaults = {
	DEFAULT_MAX_CHUNK_SIZE,
	MIN_CHUNK_LENGTH,
};

export default {
	splitContentForProcessing,
	MIN_CHUNK_LENGTH,
	chunkingDefaults,
};
