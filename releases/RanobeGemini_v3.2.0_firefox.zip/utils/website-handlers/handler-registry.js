// AUTO-GENERATED LIST OF WEBSITE HANDLER MODULE PATHS
// This file is generated/maintained by dev/build.js. Add new handler files
// under this folder and the build step will pick them up automatically.
// Format: relative paths from utils/website-handlers/ used by content scripts.

export const HANDLER_MODULES = [
	"ao3-handler.js",
	"fanfiction-mobile-handler.js",
	"fanfiction-handler.js",
	"ranobes-handler.js",
	"scribblehub-handler.js",
	"webnovel-handler.js",
];
