/**
 * Backup Download Manager for Ranobe Gemini
 * Unified backup system for both popup and library UI
 * Provides download and import functionality using browser's downloads API
 */

import { debugLog, debugError } from "./logger.js";
import { novelLibrary } from "./novel-library.js";

export class BackupDownloadManager {
	constructor() {
		this.backupPrefix = "ranobe-gemini-backup-";
	}

	/**
	 * Get all available backups
	 * @returns {Promise<Array>} Array of backup metadata
	 */
	async getAvailableBackups() {
		try {
			const result = await browser.storage.local.get(null);
			const backups = [];

			for (const [key, value] of Object.entries(result)) {
				if (key.startsWith(this.backupPrefix) && value.data) {
					backups.push({
						id: value.id,
						timestamp: value.timestamp,
						dateStr: new Date(value.timestamp).toLocaleString(),
						novelCount: value.novelCount || 0,
						size: value.size || 0,
						isAutomatic: value.isAutomatic || false,
					});
				}
			}

			return backups.sort((a, b) => b.timestamp - a.timestamp);
		} catch (error) {
			debugError("Failed to get available backups:", error);
			return [];
		}
	}

	/**
	 * Download a backup file to user's Downloads folder
	 * @param {string} backupId - ID of the backup to download
	 * @returns {Promise<boolean>} Success status
	 */
	async downloadBackup(backupId) {
		try {
			// Retrieve backup data from storage
			const result = await browser.storage.local.get(backupId);
			if (!result[backupId]) {
				debugError(`Backup not found: ${backupId}`);
				return false;
			}

			const backupData = result[backupId];
			const exportData = {
				version: backupData.version || "1.0",
				exportDate: new Date().toISOString(),
				backupTimestamp: backupData.timestamp,
				novelCount: backupData.novelCount,
				novels: backupData.data || {},
			};

			// Create blob and download
			const blob = new Blob([JSON.stringify(exportData, null, 2)], {
				type: "application/json",
			});
			const url = URL.createObjectURL(blob);

			const filename = `${this.backupPrefix}${
				new Date(backupData.timestamp).toISOString().split("T")[0]
			}.json`;

			// Use downloads API to trigger save
			try {
				const downloadId = await browser.downloads.download({
					url: url,
					filename: filename,
					saveAs: true,
				});

				if (downloadId) {
					debugLog(`Backup download started: ${filename}`);
					// Clean up the URL after a short delay
					setTimeout(() => URL.revokeObjectURL(url), 1000);
					return true;
				} else {
					debugError("Failed to start backup download");
					return false;
				}
			} catch (downloadError) {
				debugError("Download API error:", downloadError);
				URL.revokeObjectURL(url);
				return false;
			}
		} catch (error) {
			debugError("Error downloading backup:", error);
			return false;
		}
	}

	/**
	 * Create and download an instant backup
	 * @returns {Promise<boolean>} Success status
	 */
	async downloadInstantBackup() {
		try {
			// Get current library data
			const allNovels = await novelLibrary.getAllNovels();
			const novelData = {};

			for (const novel of allNovels) {
				novelData[novel.id] = novel;
			}

			const exportData = {
				version: "1.0",
				exportDate: new Date().toISOString(),
				novelCount: Object.keys(novelData).length,
				novels: novelData,
			};

			// Create blob and download
			const blob = new Blob([JSON.stringify(exportData, null, 2)], {
				type: "application/json",
			});
			const url = URL.createObjectURL(blob);

			const filename = `${this.backupPrefix}${
				new Date().toISOString().split("T")[0]
			}-instant.json`;

			try {
				const downloadId = await browser.downloads.download({
					url: url,
					filename: filename,
					saveAs: true,
				});

				if (downloadId) {
					debugLog(`Instant backup download started: ${filename}`);
					setTimeout(() => URL.revokeObjectURL(url), 1000);
					return true;
				} else {
					debugError("Failed to start instant backup download");
					return false;
				}
			} catch (downloadError) {
				debugError("Download API error:", downloadError);
				URL.revokeObjectURL(url);
				return false;
			}
		} catch (error) {
			debugError("Error creating instant backup:", error);
			return false;
		}
	}

	/**
	 * Restore from a backup
	 * @param {string} backupId - ID of the backup to restore
	 * @param {string} mergeMode - 'merge', 'replace', or 'append'
	 * @returns {Promise<boolean>} Success status
	 */
	async restoreFromBackup(backupId, mergeMode = "merge") {
		try {
			const result = await browser.storage.local.get(backupId);
			if (!result[backupId]) {
				debugError(`Backup not found: ${backupId}`);
				return false;
			}

			const backupData = result[backupId];
			const restoredNovels = backupData.data || {};

			if (mergeMode === "replace") {
				// Clear all novels and restore from backup
				const allNovels = await novelLibrary.getAllNovels();
				for (const novel of allNovels) {
					await novelLibrary.deleteNovel(novel.id);
				}
			}

			// Restore novels
			for (const [novelId, novelData] of Object.entries(restoredNovels)) {
				if (mergeMode === "append") {
					// Only add new novels
					const existing = await novelLibrary.getNovelById(novelId);
					if (!existing) {
						await novelLibrary.addNovel(novelData);
					}
				} else {
					// merge or replace mode: update/add novels
					await novelLibrary.addNovel(novelData);
				}
			}

			debugLog(
				`Restored ${
					Object.keys(restoredNovels).length
				} novels (mode: ${mergeMode})`
			);
			return true;
		} catch (error) {
			debugError("Error restoring from backup:", error);
			return false;
		}
	}

	/**
	 * Delete a backup
	 * @param {string} backupId - ID of the backup to delete
	 * @returns {Promise<boolean>} Success status
	 */
	async deleteBackup(backupId) {
		try {
			await browser.storage.local.remove(backupId);

			// Update metadata
			const result = await browser.storage.local.get(
				"rg_backup_metadata"
			);
			const metadata = result["rg_backup_metadata"] || {};
			delete metadata[backupId];
			await browser.storage.local.set({
				rg_backup_metadata: metadata,
			});

			debugLog(`Backup deleted: ${backupId}`);
			return true;
		} catch (error) {
			debugError("Error deleting backup:", error);
			return false;
		}
	}
}

// Export singleton instance
export const backupDownloadManager = new BackupDownloadManager();
