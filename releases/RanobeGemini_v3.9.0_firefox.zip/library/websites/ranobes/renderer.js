/**
 * @fileoverview Ranobes Renderer Module
 * Exports card and modal renderers for Ranobes
 */

import { RanobesNovelCard } from "./novel-card.js";

/**
 * Ranobes renderer object that provides card and modal rendering
 */
export const ranobesRenderer = {
	/**
	 * Render a novel card for the library
	 * @param {Object} novel - Novel data
	 * @param {Object} options - Rendering options
	 * @returns {HTMLElement} Rendered card element
	 */
	renderCard(novel, options = {}) {
		return RanobesNovelCard.renderCard(novel, options);
	},

	/**
	 * Render library modal for a novel
	 * @param {Object} novel - Novel data
	 * @param {HTMLElement} container - Container element for the modal
	 * @param {Function} onClose - Callback when modal closes
	 */
	renderLibraryModal(novel, container, onClose) {
		// Use the RanobesNovelCard's modal method if it exists
		if (typeof RanobesNovelCard.renderLibraryModal === "function") {
			return RanobesNovelCard.renderLibraryModal(
				novel,
				container,
				onClose,
			);
		}

		// Fallback: return null to use default library modal
		return null;
	},

	/**
	 * Get custom CSS for Ranobes cards/modals
	 * @returns {string|null} CSS text or null
	 */
	getCustomCSS() {
		if (typeof RanobesNovelCard.getCustomCSS === "function") {
			return RanobesNovelCard.getCustomCSS();
		}
		return null;
	},

	/**
	 * Get shelf configuration
	 * @returns {Object} Shelf config
	 */
	get shelfConfig() {
		return RanobesNovelCard.shelfConfig;
	},
};

// Register with the global registry if available
if (typeof window !== "undefined" && window.registerCardRenderer) {
	window.registerCardRenderer("ranobes", RanobesNovelCard);
}
