/**
 * @fileoverview AO3 Renderer Module
 * Exports card and modal renderers for Archive of Our Own
 */

import { AO3CardRenderer } from "./novel-card.js";

/**
 * AO3 renderer object that provides card and modal rendering
 */
export const ao3Renderer = {
	/**
	 * Render a novel card for the library
	 * @param {Object} novel - Novel data
	 * @param {Object} options - Rendering options
	 * @returns {HTMLElement} Rendered card element
	 */
	renderCard(novel, options = {}) {
		return AO3CardRenderer.renderCard(novel, options);
	},

	/**
	 * Render library modal for a novel
	 * @param {Object} novel - Novel data
	 * @param {HTMLElement} container - Container element for the modal
	 * @param {Function} onClose - Callback when modal closes
	 */
	renderLibraryModal(novel, container, onClose) {
		// Use the AO3CardRenderer's modal method if it exists
		if (typeof AO3CardRenderer.renderLibraryModal === "function") {
			return AO3CardRenderer.renderLibraryModal(
				novel,
				container,
				onClose,
			);
		}

		// Fallback: return null to use default library modal
		return null;
	},

	/**
	 * Get custom CSS for AO3 cards/modals
	 * @returns {string|null} CSS text or null
	 */
	getCustomCSS() {
		if (typeof AO3CardRenderer.getCustomCSS === "function") {
			return AO3CardRenderer.getCustomCSS();
		}
		return null;
	},

	/**
	 * Get shelf configuration
	 * @returns {Object} Shelf config
	 */
	get shelfConfig() {
		return AO3CardRenderer.shelfConfig;
	},
};

// Register with the global registry if available
if (typeof window !== "undefined" && window.registerCardRenderer) {
	window.registerCardRenderer("ao3", AO3CardRenderer);
}
