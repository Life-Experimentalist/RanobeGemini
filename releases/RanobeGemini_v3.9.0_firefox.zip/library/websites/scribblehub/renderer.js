/**
 * @fileoverview ScribbleHub Renderer Module
 * Exports card and modal renderers for ScribbleHub
 */

import { ScribbleHubNovelCard } from "./novel-card.js";

/**
 * ScribbleHub renderer object that provides card and modal rendering
 */
export const scribblehubRenderer = {
	/**
	 * Render a novel card for the library
	 * @param {Object} novel - Novel data
	 * @param {Object} options - Rendering options
	 * @returns {HTMLElement} Rendered card element
	 */
	renderCard(novel, options = {}) {
		return ScribbleHubNovelCard.renderCard(novel, options);
	},

	/**
	 * Render library modal for a novel
	 * @param {Object} novel - Novel data
	 * @param {HTMLElement} container - Container element for the modal
	 * @param {Function} onClose - Callback when modal closes
	 */
	renderLibraryModal(novel, container, onClose) {
		// Use the ScribbleHubNovelCard's modal method if it exists
		if (typeof ScribbleHubNovelCard.renderLibraryModal === "function") {
			return ScribbleHubNovelCard.renderLibraryModal(
				novel,
				container,
				onClose,
			);
		}

		// Fallback: return null to use default library modal
		return null;
	},

	/**
	 * Get custom CSS for ScribbleHub cards/modals
	 * @returns {string|null} CSS text or null
	 */
	getCustomCSS() {
		if (typeof ScribbleHubNovelCard.getCustomCSS === "function") {
			return ScribbleHubNovelCard.getCustomCSS();
		}
		return null;
	},

	/**
	 * Get shelf configuration
	 * @returns {Object} Shelf config
	 */
	get shelfConfig() {
		return ScribbleHubNovelCard.shelfConfig;
	},
};

// Register with the global registry if available
if (typeof window !== "undefined" && window.registerCardRenderer) {
	window.registerCardRenderer("scribblehub", ScribbleHubNovelCard);
}
