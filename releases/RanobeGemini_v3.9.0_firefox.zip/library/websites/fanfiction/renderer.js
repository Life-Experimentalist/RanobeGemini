/**
 * @fileoverview FanFiction.net Renderer Module
 * Exports card and modal renderers for FanFiction.net
 */

import { FanFictionNovelCard } from "./novel-card.js";

/**
 * FanFiction.net renderer object that provides card and modal rendering
 */
export const fanfictionRenderer = {
	/**
	 * Render a novel card for the library
	 * @param {Object} novel - Novel data
	 * @param {Object} options - Rendering options
	 * @returns {HTMLElement} Rendered card element
	 */
	renderCard(novel, options = {}) {
		return FanFictionNovelCard.renderCard(novel, options);
	},

	/**
	 * Render library modal for a novel
	 * @param {Object} novel - Novel data
	 * @param {HTMLElement} container - Container element for the modal
	 * @param {Function} onClose - Callback when modal closes
	 */
	renderLibraryModal(novel, container, onClose) {
		// Use the FanFictionNovelCard's modal method if it exists
		if (typeof FanFictionNovelCard.renderLibraryModal === "function") {
			return FanFictionNovelCard.renderLibraryModal(
				novel,
				container,
				onClose,
			);
		}

		// Fallback: return null to use default library modal
		return null;
	},

	/**
	 * Get custom CSS for FanFiction cards/modals
	 * @returns {string|null} CSS text or null
	 */
	getCustomCSS() {
		if (typeof FanFictionNovelCard.getCustomCSS === "function") {
			return FanFictionNovelCard.getCustomCSS();
		}
		return null;
	},

	/**
	 * Get shelf configuration
	 * @returns {Object} Shelf config
	 */
	get shelfConfig() {
		return FanFictionNovelCard.shelfConfig;
	},
};

// Register with the global registry if available
if (typeof window !== "undefined" && window.registerCardRenderer) {
	window.registerCardRenderer("fanfiction", FanFictionNovelCard);
}
